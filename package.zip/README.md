# fxos-cracked
Addon for Firefox OS that gives the illusion of having a cracked screen.
